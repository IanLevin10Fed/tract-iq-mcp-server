/**
 * Formats raw Tract IQ scraped data into clean, structured responses
 * suitable for Claude analysis and self-storage underwriting.
 */

function parseNumber(str) {
  if (!str) return null;
  const cleaned = String(str).replace(/[,$%]/g, '').trim();
  const num = parseFloat(cleaned);
  return isNaN(num) ? null : num;
}

function formatCurrency(num) {
  if (num == null) return 'N/A';
  return '$' + num.toLocaleString();
}

function formatPercent(num) {
  if (num == null) return 'N/A';
  return num + '%';
}

/**
 * Parses stat blocks from the executive summary extraction.
 * Tract IQ stat blocks are usually "Label\nValue" pairs.
 */
function parseStatBlocks(statBlocks) {
  const parsed = {};
  if (!Array.isArray(statBlocks)) return parsed;

  statBlocks.forEach(block => {
    const lines = block.split('\n').map(l => l.trim()).filter(Boolean);
    if (lines.length >= 2) {
      const label = lines[0].toLowerCase().replace(/[\s\/]+/g, '_');
      const value = lines[1];
      parsed[label] = value;
    }
  });
  return parsed;
}

/**
 * Parse raw text for radius-specific data.
 * Tract IQ usually shows a tab or section for 3/5/10 mile radius.
 */
function parseRadiusData(rawText) {
  if (!rawText) return {};

  const radii = {};
  const radiusSections = ['3', '5', '10'];

  radiusSections.forEach(r => {
    const pattern = new RegExp(
      `${r}[\\s-]?mile[\\s\\S]{0,500}?(?=${radiusSections.filter(x => x !== r).map(x => x + '[\\s-]?mile').join('|')}|$)`,
      'i'
    );
    const match = rawText.match(pattern);
    if (!match) return;

    const section = match[0];
    const data = {};

    // Facilities
    const fac = section.match(/facilit(?:ies|y)[:\s]+(\d+)/i) ||
                section.match(/(\d+)\s+facilit/i);
    if (fac) data.facilities = parseInt(fac[1]);

    // Square footage
    const sf = section.match(/(?:total\s+)?(?:rentable\s+)?(?:sq\s*ft|sqft)[:\s]+([\d,]+)/i) ||
               section.match(/([\d,]+)\s+(?:sq\s*ft|sqft)/i);
    if (sf) data.squareFootage = sf[1].replace(/,/g, '');

    // Occupancy
    const occ = section.match(/occupancy[:\s]+([\d.]+)%/i) ||
                section.match(/([\d.]+)%\s+occup/i);
    if (occ) data.occupancyRate = occ[1] + '%';

    // SF per capita
    const sfpc = section.match(/sf\s+per\s+capita[:\s]+([\d.]+)/i) ||
                 section.match(/([\d.]+)\s+sf\s+per\s+capita/i);
    if (sfpc) data.sfPerCapita = parseFloat(sfpc[1]);

    // Population
    const pop = section.match(/population[:\s]+([\d,]+)/i) ||
                section.match(/([\d,]+)\s+(?:residents?|people)/i);
    if (pop) data.population = pop[1].replace(/,/g, '');

    radii[`${r}-mile`] = data;
  });

  return radii;
}

/**
 * Parse rental comps from raw scrape output.
 * Tries to build a clean table of comparable facilities.
 */
function parseComps(compsRaw) {
  if (!compsRaw || !Array.isArray(compsRaw.comps)) return [];

  return compsRaw.comps
    .filter(c => c && (c.name || c.raw))
    .map(c => {
      if (c.name || c.distance || c.rate) {
        return {
          name: c.name || 'Unknown',
          distance: c.distance || 'N/A',
          rate: c.rate || 'N/A',
          size: c.size || 'N/A',
        };
      }

      // Try to parse from raw text
      const raw = c.raw || '';
      const distMatch = raw.match(/([\d.]+)\s*mi(?:le)?s?/i);
      const rateMatch = raw.match(/\$([\d.]+)(?:\/mo|\/month)?/i);
      const nameMatch = raw.split('\n')[0];

      return {
        name: nameMatch?.substring(0, 50) || 'Unknown',
        distance: distMatch ? distMatch[1] + ' mi' : 'N/A',
        rate: rateMatch ? '$' + rateMatch[1] : 'N/A',
        raw: raw.substring(0, 100),
      };
    })
    .slice(0, 15);
}

/**
 * Main formatter: takes raw scraped data and returns a clean structured object
 * ready for Claude to analyze.
 */
export function formatPropertyData(raw) {
  if (!raw) return { error: 'No data returned from scraper' };

  const { address, url, timestamp, executiveSummary, demographics, rentalComps, supplyData } = raw;

  // Parse stat blocks and radius data from executive summary
  const statsParsed = parseStatBlocks(executiveSummary?.statBlocks || []);
  const radiusData = parseRadiusData(executiveSummary?.rawText || supplyData?.rawText || '');

  // Build supply section
  const supply = {
    byRadius: Object.keys(radiusData).length > 0 ? radiusData : null,
    facilities: supplyData?.facilities || statsParsed?.facilities,
    totalSF: supplyData?.totalSF || statsParsed?.total_sf,
    occupancyRate: supplyData?.occupancyRate || statsParsed?.occupancy,
    sfPerCapita: supplyData?.sfPerCapita || statsParsed?.sf_per_capita,
    pipeline: supplyData?.pipeline || null,
    opportunityScore: supplyData?.opportunityScore || null,
    rawStats: executiveSummary?.stats || [],
  };

  // Build demographics section
  const demo = {
    population: {
      '3-mile': demographics?.population3mi || null,
      '5-mile': demographics?.population5mi || null,
      '10-mile': demographics?.population10mi || null,
    },
    medianIncome: demographics?.medianIncome || null,
    avgIncome: demographics?.avgIncome || null,
    households: demographics?.households || null,
    renterPct: demographics?.renterPct || null,
    ownerPct: demographics?.ownerPct || null,
    populationGrowth: demographics?.popGrowth || null,
    incomeGrowth: demographics?.incomeGrowth || null,
    tables: demographics?.tables || [],
  };

  // Build comps section
  const comps = parseComps(rentalComps);

  return {
    address,
    url,
    timestamp,
    supply,
    demographics: demo,
    rentalComps: comps,
    rateTrends: rentalComps?.rateTrends || [],
    _debug: {
      rawSupplyStats: supply.rawStats?.slice(0, 10),
      rawDemoText: demographics?.rawText?.substring(0, 500),
      rawCompsText: rentalComps?.rawText?.substring(0, 500),
    },
  };
}

/**
 * Formats the structured data as a clean markdown report for Claude responses.
 */
export function formatMarkdownReport(data, reportType = 'full') {
  if (data.error) return `❌ Error: ${data.error}`;

  const lines = [];
  lines.push(`# Tract IQ Market Report`);
  lines.push(`**Address:** ${data.address}`);
  lines.push(`**Generated:** ${new Date(data.timestamp).toLocaleString()}`);
  lines.push(`**Source:** ${data.url}`);
  lines.push('');

  // SUPPLY SECTION
  lines.push('## 📦 Supply & Occupancy');
  if (data.supply.byRadius) {
    Object.entries(data.supply.byRadius).forEach(([radius, d]) => {
      lines.push(`\n### ${radius} Radius`);
      if (d.facilities) lines.push(`- **Facilities:** ${d.facilities}`);
      if (d.squareFootage) lines.push(`- **Total SF:** ${parseInt(d.squareFootage).toLocaleString()}`);
      if (d.occupancyRate) lines.push(`- **Occupancy Rate:** ${d.occupancyRate}`);
      if (d.sfPerCapita) lines.push(`- **SF Per Capita:** ${d.sfPerCapita}`);
      if (d.population) lines.push(`- **Population:** ${parseInt(d.population).toLocaleString()}`);
    });
  } else {
    // Flat supply data
    if (data.supply.facilities) lines.push(`- **Facilities:** ${data.supply.facilities}`);
    if (data.supply.totalSF) lines.push(`- **Total SF:** ${data.supply.totalSF}`);
    if (data.supply.occupancyRate) lines.push(`- **Occupancy Rate:** ${data.supply.occupancyRate}`);
    if (data.supply.sfPerCapita) lines.push(`- **SF Per Capita:** ${data.supply.sfPerCapita}`);
    if (data.supply.pipeline) lines.push(`- **Pipeline/New Supply:** ${data.supply.pipeline}`);
    if (data.supply.opportunityScore) lines.push(`- **Opportunity Score:** ${data.supply.opportunityScore}`);
  }

  if (data.supply.rawStats?.length > 0) {
    lines.push('\n**All Stat Blocks:**');
    data.supply.rawStats.forEach(s => {
      if (s.label && s.value) lines.push(`- ${s.label}: ${s.value}`);
    });
  }

  // DEMOGRAPHICS SECTION
  if (reportType !== 'supply_only') {
    lines.push('\n## 👥 Demographics & Income');
    const d = data.demographics;

    const popEntries = Object.entries(d.population || {}).filter(([, v]) => v);
    if (popEntries.length > 0) {
      lines.push('\n**Population:**');
      popEntries.forEach(([r, v]) => lines.push(`- ${r}: ${parseInt(v).toLocaleString()}`));
    }

    if (d.medianIncome) lines.push(`\n**Median Household Income:** $${parseInt(d.medianIncome.replace(/,/g, '')).toLocaleString()}`);
    if (d.avgIncome) lines.push(`**Average Household Income:** $${parseInt(d.avgIncome.replace(/,/g, '')).toLocaleString()}`);
    if (d.households) lines.push(`**Households:** ${parseInt(d.households.replace(/,/g, '')).toLocaleString()}`);
    if (d.renterPct) lines.push(`**Renter %:** ${d.renterPct}%`);
    if (d.ownerPct) lines.push(`**Owner %:** ${d.ownerPct}%`);
    if (d.populationGrowth) lines.push(`**Population Growth:** ${d.populationGrowth}%`);
    if (d.incomeGrowth) lines.push(`**Income Growth:** ${d.incomeGrowth}%`);

    if (d.tables?.length > 0) {
      lines.push('\n**Data Tables:**');
      d.tables.slice(0, 3).forEach((table, i) => {
        lines.push(`\n_Table ${i + 1}:_`);
        table.forEach(row => lines.push('| ' + row.join(' | ') + ' |'));
      });
    }
  }

  // RENTAL COMPS SECTION
  if (reportType !== 'supply_only' && reportType !== 'demographics_only') {
    lines.push('\n## 🏪 Rental Comparables');
    if (data.rentalComps?.length > 0) {
      lines.push('| Name | Distance | Rate | Size |');
      lines.push('|------|----------|------|------|');
      data.rentalComps.forEach(c => {
        lines.push(`| ${c.name} | ${c.distance} | ${c.rate} | ${c.size || 'N/A'} |`);
      });
    } else {
      lines.push('_No rental comps extracted — may require navigating to Comps tab manually._');
    }

    if (data.rateTrends?.length > 0) {
      lines.push('\n**Rate Trends:**');
      data.rateTrends.slice(0, 5).forEach(t => lines.push(`- ${t}`));
    }
  }

  lines.push('\n---');
  lines.push('_Data extracted live from Tract IQ via browser automation._');

  return lines.join('\n');
}
